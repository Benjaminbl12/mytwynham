//
//  ViewController.swift
//  MyTwynham
//
//  Created by Ben Blackmore on 06/11/2018.
//  Copyright © 2018 BMORE Software. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
    }
    
    
}

